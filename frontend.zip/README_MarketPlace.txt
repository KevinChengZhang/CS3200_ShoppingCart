MARKET PLACE


----------------------------------------- READ ME ----------------------------------------
                                       |Instructions|

1.  Host machine needs to have MySQL installed

2.  Host machine need to have Python 3 installed

3.  Python 3 needs to have PyMySQL libraries installed more detail can be found here 
    https://pymysql.readthedocs.io/en/latest/

4.  Python 3 also needs to have tabulated libraries installed more detail can be found here 
    https://pypi.org/project/tabulate/

5.  Download database schema  MySQL script

6.  Download database function and procedure MySQL script

7.  Run Data schema script for MySQL to create a database and add sample data entries

8.  Run Function and Procedures script to create database function and procedures

9.  Download All Frontend Code to Preferred directory

10. Go to the directory in terminal

11. Run command Python3 run.py to start the application

12. Enter any customer login information as prompt to login

13. Run application command as needed according to frontend specifications
