from getpass import getpass
from sys import exit

class CartController:
    """
    Controls the front and backend of the shopping cart and handles interfacig with user
    """

    def __init__(self, model, view):
        self.model = model
        self.view = view

    def run(self):
        self.promptCustomerSignin()
        self.listCommands()
        while True:
            userCommand = input("Please input a command: ")
            self.runCommand(userCommand.lower().split("-"))

    def promptCustomerSignin(self):
        while True:
            username = input("Please Input username: ")
            password = getpass("Please Input Password: ")
            try:
                success = self.model.customerSignin(username, password)
                if success:
                    print("Login successful, Welcome\n\n")
                    break
                print("Failed to login, Like to try again?")
                retry = input("Y/N: ")
                if retry.upper() == "N" or retry.upper() == "NO":
                    break
            except Exception as e:
                print(e.customMessage)

    def listCommands(self):
        print("Commands are in the form: keyword seperated by -")
        print("Example: show-cart\n")
        print("Following is the list of commands:")
        print("Show: all, seller-<seller name>, warehouse-<warehouse name>")
        print("Show: cart, wish, favcategory, favseller, passmonthspending")
        print("Add: cart-<item name>-<quantity>, wish-<item name>")
        print("Remove: cart-<item name>, wish-<item name>")
        print("Edit: cart-<item name-<quantity>")
        print("Placeorder\n")
        print("Use Command <Help> to show this list again")
        print("Use Command <Quit> to exit application\n")


    def runCommand(self, instructionList):
        commandSwitcher = {
            "show": {
                "all": self.view.listAllItems,
                "seller": self.view.listBySeller,
                "warehouse": self.view.listByWarehouse,
                "cart": self.view.listCartItems,
                "wish": self.view.listWishItems,
                "favcategory": self.view.favCategory,
                "favseller": self.view.favSeller,
                "passmonthspending": self.view.passMonthSpending
            },
            "add": {
                "cart": self.model.addCartItem,
                "wish": self.model.addWishItem,
            },
            "remove": {
                "cart": self.model.removeCartItem,
                "wish": self.model.removeWishItem,
            },
            "edit":{
                "cart":self.model.editCartItem
            },
            "placeorder": self.model.placeOrder,
            "quit": lambda: exit("Application finished"),
            "help": self.listCommands
        }
        try:
            command = commandSwitcher
            for instruction in instructionList[:2]:
                command = command[instruction]
            numInstruction = len(instructionList)
            if numInstruction == 3:
                command(instructionList[2])
            elif numInstruction == 4:
                command(instructionList[2], instructionList[3])
            else:
                command() 
        except Exception as e:
            print("Invalid Command!!\n")