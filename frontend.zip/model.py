import pymysql
from datetime import datetime

class ShoppingCart:
    """
    A ShoppingCart holds the connection objects to the backend database and provides the essential query and functionality interfaces to the market place data.
    """

    def __init__(self, dbUsername, dbPassword, host, database):
        """
        Initiates a connection to the shopping cart database with the provided username and password and configures the connection object and cursor object accordingly.

        Returns True, On successfuly connection to the backend database with the given credentials 
        Returns False, On Failed connection to backend database
        """
        if dbUsername == None or dbPassword == None or host == None or database == None:
            raise TypeError("NoneType Input")
        try:
            cnx = pymysql.connect(host=host, user=dbUsername, password=dbPassword,
                                    db=database, charset="utf8mb4", cursorclass=pymysql.cursors.DictCursor)
            self.connection = cnx
            self.cursor = cnx.cursor()
            self.user = None
        except Exception as e:
            e.customMessage = "Database Connection Failed"
            raise

    def __del__(self):
        """
        Closes backend connection to database
        """
        self.cursor.close()
        self.connection.commit()
        self.connection.close()

    def customerSignin(self, customerLogin, customerPassword):
        """
        Customer sign in using the given credentials
        Return True on success False on failed signin
        """
        if customerLogin == None or customerPassword == None:
            raise TypeError("NoneType Input")
        try:
            self.cursor.execute("select login, pass, user_id from customer")
            for customer in self.cursor.fetchall():
                if customer["login"] == customerLogin and customer["pass"] == customerPassword:
                    self.user = customer["user_id"]
                    return True
            return False
        except Exception as e:
            e.customMessage = "Error with customer login data retrieval"
            raise

    def listAllItems(self):
        """
        Shows the whole list of available items in the market place with all available information on each.
        """
        try:
            self.cursor.callproc("browseItems")
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error listing all items"
            raise

    def listBySeller(self, seller):
        """
        Shows the list of items available for sale from the given seller.
        """
        if seller == None:
            raise TypeError("NoneType Input")
        try:
            self.cursor.callproc("browseSeller", (seller,))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error listing item by seller"
            raise

    def listByWarehouse(self, warehouse):
        """
        Shows the list of items available for sale from the given warehouse.
        """
        if warehouse == None:
            raise TypeError("NoneType Input")
        try:
            self.cursor.callproc("browseWarehouse", (warehouse,))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error listing item by warehouse"
            raise

    def listCartItems(self):
        """
        Shows the list of items currently in the shopping cart and the total price
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("showCart", (self.user,))
            cartItems = self.cursor.fetchall()
            totalPrice = 0
            for item in cartItems:
                totalPrice += item["item_price"] * item["quantity"]
            return {"items":cartItems, "totalPrice":totalPrice}
        except Exception as e:
            e.customMessage = "Database error listing customer shopping cart"
            raise

    def listWishItems(self):
        """
        Shows the list of items in the wishlist and total price
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("showWish", (self.user,))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error listing customer wishlist"
            raise

    def addCartItem(self, item, quantity):
        """
        Add the item with the specified quantity to the shopping cart.
        """
        if item == None or quantity == None:
            raise TypeError("NoneType Input")
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("addCartitem", (self.user, item, quantity))
        except Exception as e:
            e.customMessage = "Database error adding to customer shopping cart" 
            raise

    def addWishItem(self, item):
        """
        Add the item to the wish list.
        """
        if item == None:
            raise TypeError("NoneType Input")
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("addWishitem", (self.user, item))
        except Exception as e:
            e.customMessage = "Database error adding to customer wish list"
            raise

    def removeCartItem(self, item):
        """
        Removes the specified item from the shopping cart
        """
        if item == None:
            raise TypeError("NoneType Input")
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("deleteCartitem", (self.user, item))
        except Exception as e:
            e.customMessage = "Database error removing item from customer shopping cart"
            raise

    def removeWishItem(self, item):
        """
        Removes the specified item from the wish list
        """
        if item == None:
            raise TypeError("NoneType Input")
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("deleteWishitem", (self.user, item))
        except Exception as e:
            e.customMessage = "Database error removing item from customer wish list"
            raise

    def editCartItem(self, item, newQuantity):
        """
        Edits the quantity in the shopping cart of the specified item
        """
        if item == None or newQuantity == None:
            raise TypeError("NoneType Input")
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("editCartitems", (self.user, item, newQuantity))
        except Exception as e:
            e.customMessage = "Database error editing customer shopping cart item"
            raise

    def placeOrder(self):
        """
        Places the order of the list of items in the shopping cart on the specified date
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            today = datetime.today()
            orderDate = "{}-{}-{}".format(today.year, today.month, today.day)
            self.cursor.callproc("confirmOrder", (self.user, orderDate))
        except Exception as e:
            e.customMessage = "Database error placing customer order"
            raise

    def favCategory(self):
        """
        Find the customers favorite item category and how much they spent on it
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as customer first")
        try:
            self.cursor.callproc("favCategory", (self.user,))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error finding customer favorite category"
            raise

    def favSeller(self):
        """
        Find the customers favorite seller brand and how much they spent on it
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as a customer first")
        try:
            self.cursor.callproc("favSeller", (self.user,))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error finding customer favorite seller"
            raise

    def passMonthSpending(self):
        """
        Finds how much the customer spent in the past month
        """
        if self.user == None:
            raise RuntimeError("Need to sign in as a customer first")
        try:
            today = datetime.today()
            curDate = "{}-{}-{}".format(today.year, today.month, today.day)
            self.cursor.callproc("pastMonth", (self.user, curDate))
            return self.cursor.fetchall()
        except Exception as e:
            e.customMessage = "Database error finding customer pass month spending"
            raise