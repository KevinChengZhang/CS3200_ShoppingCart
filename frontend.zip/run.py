from model import ShoppingCart
from control import CartController
from view import CartTextView

def main():
    cart = ShoppingCart("root", "Jingpass1314520", "localhost", "shopping_cart")
    cartView = CartTextView(cart)
    controller = CartController(cart, cartView)
    controller.run()

if __name__ == "__main__":
    main()