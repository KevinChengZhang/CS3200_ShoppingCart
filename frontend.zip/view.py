from tabulate import tabulate

class CartTextView:
    """
    A command line text few for displaying cart contents
    """
    def __init__(self, model):
        self.model = model

    def listAllItems(self):
        allItems = self.model.listAllItems()
        headers = ["item name", "item price", "item seller", "stored warehouse"]
        table = []
        for item in allItems:
            row = [item["item_name"], item["item_price"], item["sellername"], item["warehousename"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def listBySeller(self, seller):
        allItems = self.model.listBySeller(seller)
        headers = ["item name", "item price"]
        table = []
        for item in allItems:
            row = [item["item_name"],item["item_price"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def listByWarehouse(self, warehouse):
        allItems = self.model.listByWarehouse(warehouse)
        headers = ["item name", "item price"]
        table = []
        for item in allItems:
            row = [item["item_name"],item["item_price"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def listCartItems(self):
        allContent = self.model.listCartItems()
        allItems = allContent["items"]
        totalPrice = allContent["totalPrice"]
        headers = ["item name", "item price", "quantity"]
        table = []
        for item in allItems:
            row = [item["item_name"],item["item_price"],item["quantity"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print("Cart Total: {}".format(totalPrice))
        print()

    def listWishItems(self):
        allItems = self.model.listWishItems()
        headers = ["item name", "item price"]
        table = []
        for item in allItems:
            row = [item["item_name"],item["price"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def favCategory(self):
        allItems = self.model.favCategory()
        headers = ["category", "total spent"]
        table = []
        for item in allItems:
            row = [item["category"],item["total"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def favSeller(self):
        allItems = self.model.favSeller()
        headers = ["seller", "total spent"]
        table = []
        for item in allItems:
            row = [item["seller"],item["total"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()

    def passMonthSpending(self):
        allItems = self.model.passMonthSpending()
        headers = ["total spent"]
        table = []
        for item in allItems:
            row = [item["sum(total)"]]
            table.append(row)
        print(tabulate(table, headers, tablefmt="grid"))
        print()